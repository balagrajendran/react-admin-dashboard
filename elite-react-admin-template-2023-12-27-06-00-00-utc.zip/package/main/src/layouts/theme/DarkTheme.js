import React from 'react';
import '../../assets/scss/styledark.scss';

const DarkTheme = () => {
  return <></>;
};

export default DarkTheme;
