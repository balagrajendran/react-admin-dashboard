import React from 'react';
import { Card, CardBody } from 'reactstrap';


const StarterKit = () => {
  return (
    <>
      
      <Card>
        <CardBody className='p-4'>
          <p className='mb-0'>This is some text within a card block.</p>
        </CardBody>
      </Card>
    </>
  );
};

export default StarterKit;
