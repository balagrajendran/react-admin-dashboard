declare module "feather-icons-react";
declare module "react-draft-wysiwyg";
declare module "react-sweetalert2";
declare module "google-maps-react";
